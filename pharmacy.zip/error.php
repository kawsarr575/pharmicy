<?php


echo "Your are not allow this page";