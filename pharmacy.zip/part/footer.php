    


    <footer class="footer">
        <div class="container">
            All Right Reserved <a href="#">Pharmacy</a>
        </div>
    </footer>


    <script src="assets/js/jquery-min.js"></script>
    <script src="assets/js/bootstrap-min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="assets/js/bootsrap-proper-min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="assets/js/main.js"></script>
    
    </body>
</html>